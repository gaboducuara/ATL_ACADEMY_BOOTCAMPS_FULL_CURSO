package com.atl_Academy.boocamp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoocampApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoocampApplication.class, args);
	}

}
