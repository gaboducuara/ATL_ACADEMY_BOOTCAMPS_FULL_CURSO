package com.atl_Academy.boocamp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoocampApplicationTests {

	@Test
	void contextLoads() {
	}

}
