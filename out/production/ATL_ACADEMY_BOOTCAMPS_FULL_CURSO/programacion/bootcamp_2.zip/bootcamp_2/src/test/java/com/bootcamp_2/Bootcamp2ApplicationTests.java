package com.bootcamp_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bootcamp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
